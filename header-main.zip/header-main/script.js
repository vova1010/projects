document.addEventListener("DOMContentLoaded", function () {
  const burger = document.querySelector(".header__burger");
  const menu = document.querySelector(".header__menu");
  const body = document.body;
  const links = document.querySelectorAll(".header__link");
  const logo = document.querySelector(".header__logo");

  function toggleMenu() {
    burger.classList.toggle("active");
    menu.classList.toggle("active");
    body.classList.toggle("lock");
  }

  function closeMenu() {
    burger.classList.remove("active");
    menu.classList.remove("active");
    body.classList.remove("lock");
  }

  burger.addEventListener("click", toggleMenu);

  links.forEach(link => {
    link.addEventListener("click", () => {
      if (window.innerWidth < 992) closeMenu();
    });
  });

  logo.addEventListener("click", () => {
    if (window.innerWidth < 992) closeMenu();
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth >= 992) {
      closeMenu();
    }
  });
});